<?php
defined('ABSPATH') or die;
/**
 * Page template with raw html
 */

global $post;
$data_provider = np_data_provider($post->ID);
$headerNp = get_option('headerNp', true);
$footerNp = get_option('footerNp', true);
$tmpPath = get_template_directory();

$headerItem = '';
if ($headerNp && !$data_provider->getHideHeader()) {
    $headerItem = json_decode($headerNp, true);
    $publishHeader = $headerItem['php'];
    $publishHeader = Nicepage::processContent($publishHeader);
}
$footerItem = '';
if ($footerNp && !$data_provider->getHideFooter()) {
    $footerItem = json_decode($footerNp, true);
    $publishFooter = $footerItem['php'];
    $publishFooter = Nicepage::processContent($publishFooter);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body class="<?php echo $data_provider->getPageBodyClass(); ?>"
      style="<?php echo $data_provider->getPageBodyStyle(); ?>">
<?php the_post();
if (NpMetaOptions::get($post->ID, 'np_template') === 'html') {
    if ($headerItem) {
        echo $headerItem['styles'];
        echo $publishHeader;
    }
    the_content();
    if ($footerItem) {
        echo $footerItem['styles'];
        echo $publishFooter;
    }
    wp_footer();
} ?>
</body>
</html>