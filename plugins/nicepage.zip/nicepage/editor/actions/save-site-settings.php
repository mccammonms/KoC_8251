<?php
defined('ABSPATH') or die;

class NpSaveSiteSettingsAction extends NpAction {

    /**
     * Process action entrypoint
     *
     * @return array
     */
    public static function process() {

        $settings = isset($_REQUEST['settings']) && is_array($_REQUEST['settings']) ? $_REQUEST['settings'] : array();
        np_data_provider()->setSiteSettings($settings);
        if (isset($settings['publishNicePageCss']) && $settings['publishNicePageCss']) {
            np_data_provider()->setStyleCss($settings['publishNicePageCss'], '');
        }
        return array(
            'result' => 'done',
        );
    }
}
NpAction::add('np_save_site_settings', 'NpSaveSiteSettingsAction');