<?php
defined('ABSPATH') or die;

class NpSavePageAction extends NpAction {

    /**
     * Process action entrypoint
     *
     * @return array
     *
     * @throws Exception
     */
    public static function process() {

        include_once dirname(__FILE__) . '/chunk.php';

        $saveType = $_REQUEST['saveType'];
        switch($saveType) {
        case 'base64':
            $_REQUEST = array_merge($_REQUEST, json_decode(base64_decode($_REQUEST['data']), true));
            break;
        case 'chunks':
            $chunk = new NpChunk();
            $ret = $chunk->save(self::_getChunkInfo($_REQUEST));
            if (is_array($ret)) {
                return self::_response(array($ret));
            }
            if ($chunk->last()) {
                $result = $chunk->complete();
                if ($result['status'] === 'done') {
                    $_REQUEST = array_merge($_REQUEST, json_decode(base64_decode($result['data']), true));
                } else {
                    $result['result'] = 'error';
                    return self::_response(array($result));
                }
            } else {
                return self::_response('processed');
            }
            break;
        default:
        }

        if (!isset($_REQUEST['id']) || !isset($_REQUEST['data'])) {
            return array(
                'status' => 'error',
                'message' => 'post parameter missing',
            );
        }

        $request = stripslashes_deep($_REQUEST);
        $post_id = $request['id'];
        if (isset($request['pageType'])) {
            $pageType = $request['pageType'];
            $getCmsValue = array(
                'theme-template' => '',
                'np-template-header-footer-from-plugin' => 'html',
                'np-template-header-footer-from-theme' => 'html-header-footer'
            );
            NpMetaOptions::update($post_id, 'np_template', $getCmsValue[$pageType]);
        }
        $title = _arr($request, 'title', '');
        $data = &$request['data'];
        $fullRequest = &$request;

        if ($post_id <= 0) {
            $insert_data = array();

            $insert_data['post_type'] = 'page';
            $insert_data['post_status'] = 'publish';

            $post_id = wp_insert_post($insert_data);
            if (is_wp_error($post_id)) {
                //TODO: process error
            }
        }

        $post = get_post($post_id);

        if (!$post) {
            return array(
                'result' => 'error',
                'message' => 'There is no post with id=' . $post_id,
            );
        }

        $data_provider = np_data_provider($post_id);
        $data_provider->setSiteSettings(_arr($request, 'settings', ''));

        if ($title !== $post->post_title) {
            $title = self::_createUniqueTitle($title);
            wp_update_post(
                array(
                    'ID' => $post_id,
                    'post_title' => $title,
                    'post_status' => $post->post_status === 'auto-draft' ? 'draft' : $post->post_status,
                )
            );
            $post = get_post($post_id);
        }

        if (!$data_provider->isNicepage()) {
            $headerNp = get_option('headerNp');
            $footerNp = get_option('footerNp');
            // set our template for new page
            if ($headerNp || $footerNp) {
                $template = 'html';
            } else {
                $template = 'html-header-footer';
            }
            NpMetaOptions::update($post_id, 'np_template', $template);
        }

        $publish_html = _arr($data, 'publishHtml', '');
        if ($fullRequest['publishHeader']) {
            $fullRequest['publishHeader'] = $data_provider->setHeaderFooterPublishHtml($fullRequest['publishHeader']);
        }
        if ($fullRequest['publishFooter']) {
            $fullRequest['publishFooter'] = $data_provider->setHeaderFooterPublishHtml($fullRequest['publishFooter']);
        }
        $publishHeaderFooter = NpSavePageAction::saveHeaderFooter($fullRequest);
        $data_provider->setPagePublishHtml($publish_html);
        // Convert base64 to html, because some servers reject requests with tags - body, meta and etc.
        $data_provider->setPageHtml(base64_decode(_arr($data, 'html', '')));
        $data_provider->setPageHead(_arr($data, 'head', ''));
        $data_provider->setPageBodyClass(_arr($data, 'bodyClass', ''));
        $data_provider->setPageBodyStyle(_arr($data, 'bodyStyle', ''));

        $data_provider->setHideHeader(_arr($data, 'hideHeader', 'false'));
        $data_provider->setHideFooter(_arr($data, 'hideFooter', 'false'));

        $data_provider->setPageFonts(_arr($data, 'fonts', ''));
        $data_provider->setPageBacklink(_arr($data, 'backlink', ''));
        $data_provider->setStyleCss(_arr($data, 'publishNicePageCss', ''), $publish_html, $publishHeaderFooter);

        $data_provider->setPageKeywords(_arr($request, 'keywords', ''));
        $data_provider->setPageDescription(_arr($request, 'description', ''));
        $data_provider->setPageMetaTags(_arr($request, 'metaTags', ''));
        $data_provider->setPageCustomHeadHtml(_arr($request, 'customHeadHtml', ''));
        $data_provider->setPageTitleInBrowser(_arr($request, 'titleInBrowser', ''));

        NpForms::updateForms($post_id);

        if (!$data_provider->preview) {
            np_data_provider($post_id, true)->clear();
            // create post_content for page indexing in search
            wp_update_post(array('ID' => $post_id, 'post_content' => apply_filters('np_create_excerpt', $data_provider->getPagePublishHtml())));
            $post = get_post($post_id);
        }

        $result = self::getPost($post);
        return array(
            'result' => 'done',
            'data' => $result,
        );
    }

    /**
     * Create unique page title based on specified string
     *
     * @param string $title
     *
     * @return string
     */
    private static function _createUniqueTitle($title) {
        while (($p = get_page_by_title($title)) && $p->post_title === $title) {
            if (preg_match('#(.*\s)(\d+)$#', $title, $match)) {
                $new_title = $match[1] . ($match[2] + 1);
                if ($title === $new_title) {
                    break;
                }
                $title = $new_title;
            } else {
                $title = $title . ' 1';
            }
        }
        return $title;
    }

    /**
     * @param string|array $result Result
     *
     * @return mixed|string
     */
    private static function _response($result)
    {
        if (is_string($result)) {
            $result = array('result' => $result);
        }
        return $result;
    }

    /**
     * Get chunk info
     *
     * @param array $data Chunk data
     *
     * @return array
     */
    private static function _getChunkInfo($data)
    {
        return array(
            'id' => $data['id'],
            'content' =>  $data['content'],
            'current' =>  $data['current'],
            'total' =>  $data['total'],
            'blob' => $data['blob'] == 'true' ? true : false
        );
    }

    /**
     * Save header and footer content
     *
     * @param array $data
     *
     * @return array $result
     */
    public static function saveHeaderFooter($data)
    {
        $result = array();
        $keys = array('header', 'footer');
        $publishHeaderFooter = '';
        foreach ($keys as $key) {
            $html = $data[$key];
            $htmlCss = $data[$key.'Css'];
            $htmlPhp =  $data['publish'.ucfirst($key)];

            if ($html) {
                $result[$key] = json_encode(
                    array(
                        'html'   => $html,
                        'php'    => $htmlPhp,
                        'styles' => $htmlCss
                    )
                );
                $publishHeaderFooter .= $htmlPhp;
            } else {
                $result[$key] = "";
                if (get_option($key . 'Np')) {
                    $item = json_decode(get_option($key . 'Np'), true);
                    $publishHeaderFooter .= $item['php'];
                }
            }
        }
        // Save header and footer content data
        if ($result['header'] !== "") {
            update_option('headerNp', $result['header']);
        }
        if ($result['footer'] !== "") {
            update_option('footerNp', $result['footer']);
        }
        return $publishHeaderFooter;
    }
}

NpAction::add('np_save_page', 'NpSavePageAction');
add_filter('np_create_excerpt', 'wp_strip_all_tags');